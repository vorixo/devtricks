// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#include "KillcamPlayback.h"
#include "Components/ModelComponent.h"
#include "NetworkReplayStreaming.h"
#include "UnrealNetwork.h"
#include "Engine/DemoNetConnection.h"
#include "LocalPlayer.h"
#include "UI/GameViewportClient.h"
#include "Player/ReplaySpectator.h"
#include "Camera/SpectatorCamComp_Chase.h"
#include "HUDContext.h"
#include "Utilities/RuntimeOptions_Game.h"
#include "Game/ClientSettingsRecord.h"
#include "Engine/ActorChannel.h"
#include "Game/GameState_MOBA.h"
#include "Player/PlayerController_Game.h"
#include "Player/PlayerState_Game.h"
#include "Analytics/Analytics_Game.h"

static TAutoConsoleVariable<float> CVarKillcamRewindTime(
	TEXT("Killcam.RewindTime"),
	4.0f,
	TEXT("Number of seconds to rewind the killcam for playback.")
);

TAutoConsoleVariable<float> CVarKillcamMaxDesiredRecordTimeMS(
	TEXT("Killcam.MaxDesiredRecordTimeMS"),
	0.5f,
	TEXT("If greater than zero, the engine will attempt to not spend more time than this for recording the killcam replay.\n"));

TAutoConsoleVariable<float> CVarKillcamBufferTimeInSeconds(
	TEXT("Killcam.BufferTimeInSeconds"),
	100.0f,
	TEXT("If greater than zero, the in-memory killcam replay representation can free data that's not needed to rewind beyond this many seconds. Can help reduce memory usage.\n"));

static TAutoConsoleVariable<float> CVarKillcamAutoSwitchToLiveAfterDeathTimeInSeconds(
	TEXT("Killcam.AutoSwitchToLiveAfterDeathTimeInSeconds"),
	2.25f,
	TEXT("Number of seconds to wait after the local hero dies in the killcam world before switching back to the live world automatically."));

static TAutoConsoleVariable<int32> CVarKillcamGarbageCollectOnExit(
	TEXT("Killcam.GarbageCollectOnExit"),
	1,
	TEXT("If nonzero, run garbage collection when leaving deathcam to clean up all the objects that were just destroyed in the deathcam world."));

static TAutoConsoleVariable<float> CVarKillcamCheckpointSaveMaxMSPerFrame(
	TEXT("Killcam.CheckpointSaveMaxMSPerFrame"),
	2.0f,
	TEXT("The value used to set CheckpointSaveMaxMSPerFrame on the recording DemoNetDriver."));

static TAutoConsoleVariable<float> CVarKillcamPlaybackMinimumSecondsAfterDeath(
	TEXT("Killcam.PlaybackMinimumSecondsAfterDeath"),
	3.0f,
	TEXT("The number of seconds that a player must wait after dying before playback is allowed to start."));


int32 UKillcamPlayback::NumWorldsCreated = 0;

UKillcamPlayback::UKillcamPlayback()
	: KillcamWorld(nullptr)
	, KillcamWorldPackage(nullptr)
	, bIsEnabled(false)
	, OnWorldCleanupHandle(FWorldDelegates::OnWorldCleanup.AddUObject(this, &UKillcamPlayback::CleanUpKillcam))
	, CachedGoToTimeSeconds(0.0f)
	, CachedHeroDeathDemoTime(0.0f)
	, CachedHeroDeathClientWorldTime(0.0f)
	, LastRecordUnpauseTimeSeconds(0.0f)
	, bIsPlaying(false)
	, bIsRunningTasks(false)
{
}

void UKillcamPlayback::BeginDestroy()
{
	FWorldDelegates::OnWorldCleanup.Remove(OnWorldCleanupHandle);

	if (GEngine != nullptr)
	{
		FWorldContext* KillcamContext = GEngine->GetWorldContextFromWorld(KillcamWorld);
		if (KillcamContext != nullptr)
		{
			KillcamContext->RemoveRef(KillcamWorld);
		}
	}

	Super::BeginDestroy();
}

void UKillcamPlayback::Tick(float DeltaTime)
{
	bIsRunningTasks = true;
	for (FKillcamTaskDelegate& Task : DeferredDelegatesForNextTick)
	{
		Task.ExecuteIfBound();
	}
	bIsRunningTasks = false;

	DeferredDelegatesForNextTick.Reset();
}

bool UKillcamPlayback::IsTickable() const
{
	return true;
}

TStatId UKillcamPlayback::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(FKillcamPlaybackTick, STATGROUP_Game);
}

void UKillcamPlayback::QueueTaskForNextTick(const FKillcamTaskDelegate& Delegate)
{
	// Can't add to the task list while we're  processing tasks.
	check(!bIsRunningTasks);
	DeferredDelegatesForNextTick.Emplace(Delegate);
}

void UKillcamPlayback::PlayKillcamReplay(const FString& ReplayUniqueName)
{
	if (!URuntimeOptions_Game::Get().IsDeathcamEnabled())
	{
		return;
	}

	if (KillcamWorld == nullptr)
	{
		UE_LOG(LogKillcam, Log, TEXT("UKillcamPlayback::PlayKillcamReplay: KillcamWorld is null."));
		return;
	}
	
	if (SourceWorld.IsValid() && SourceWorld->GetNetMode() != NM_Client)
	{
		return;
	}

	UGameInstance* GameInstance = KillcamWorld->GetGameInstance();
	check(GameInstance != nullptr);

	if (GameInstance->GetWorldContext() != nullptr && GameInstance->GetWorldContext()->WorldType == EWorldType::PIE)
	{
		UE_LOG(LogKillcam, Log, TEXT("UKillcamPlayback::PlayKillcamReplay: Killcam playback is not supported for PIE."));
		return;
	}

	TArray<FString> AdditionalOptions;
	AdditionalOptions.Add(TEXT("ReplayStreamerOverride=") + GetKillcamReplayStreamerName());
	// Currently, loading the killcam world seamlessly is not supported, so force a synchronous load for now
	AdditionalOptions.Add(TEXT("AsyncLoadWorldOverride=0"));

	OnPostLoadMapHandle = FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UKillcamPlayback::OnPostLoadMap);
	GameInstance->PlayReplay(ReplayUniqueName, KillcamWorld, AdditionalOptions);
}

void UKillcamPlayback::KillcamStart(FOnKillcamStartComplete Delegate)
{
	QueueTaskForNextTick(FKillcamTaskDelegate::CreateUObject(this, &UKillcamPlayback::KillcamStart_Internal, Delegate));
}

void UKillcamPlayback::KillcamStart_Internal(FOnKillcamStartComplete Delegate)
{
	if (!IsPlaybackAllowed())
	{
		Delegate.ExecuteIfBound(false);
		return;
	}

	UWorld* const CachedSourceWorld = SourceWorld.Get();

	// We should always have a world.
	if (!ensure(CachedSourceWorld != nullptr))
	{
		Delegate.ExecuteIfBound(false);
		return;
	}

	UGameInstance* const GameInstance = CachedSourceWorld->GetGameInstance();

	// We should always have a game instance.
	if (!ensure(GameInstance != nullptr))
	{
		Delegate.ExecuteIfBound(false);
		return;
	}

	FLevelCollection* const DuplicateCollection = CachedSourceWorld->FindCollectionByType(ELevelCollectionType::DynamicDuplicatedLevels);
	
	// Nothing to do if there aren't any duplicated levels in which to play the replay.
	if (!DuplicateCollection)
	{
		Delegate.ExecuteIfBound(false);
		return;
	}

	// Cache GUIDs to preserve here before the recording DemoNetDriver is destroyed.
	SavedNonQueuedGUIDs.Empty();

	if(CachedSourceWorld->GetDemoNetDriver() != nullptr)
	{
		// Don't queue bunches for always relevant actors
		for (FActorIterator It(CachedSourceWorld); It; ++It)
		{
			if (It->bAlwaysRelevant)
			{
				const FNetworkGUID ActorGUID = CachedSourceWorld->GetDemoNetDriver()->GetGUIDForActor(*It);
				SavedNonQueuedGUIDs.Add(ActorGUID);
			}
		}
	}

	SavedNonQueuedGUIDs.Add(CachedFocusActorGUID);
	SavedNonQueuedGUIDs.Add(CachedKillingActorGUID);

	// Save the time to scrub to in case this replay is restarted
	CachedGoToTimeSeconds = CachedHeroDeathDemoTime - CVarKillcamRewindTime.GetValueOnGameThread();

	// Stop recording
	GameInstance->StopRecordingReplay();

	bIsPlaying = true;

	// Make duplicated levels visible	
	DuplicateCollection->SetIsVisible(true);

	for (ULevel* DuplicateLevel : DuplicateCollection->GetLevels())
	{
		while (!DuplicateLevel->bIsVisible)
		{
			CachedSourceWorld->AddToWorld(DuplicateLevel);
		}
	}

	// Start playback with overridden levels
	TArray<FString> AdditionalOptions;
	AdditionalOptions.Add(TEXT("ReplayStreamerOverride=") + GetKillcamReplayStreamerName());
	// Currently, loading the killcam world seamlessly is not supported, so force a synchronous load for now
	AdditionalOptions.Add(TEXT("AsyncLoadWorldOverride=0"));

	// Re-use levels using a PIE prefix, assuming they're already loaded
	AdditionalOptions.Add(TEXT("LevelPrefixOverride=1"));

	OnPostLoadMapHandle = FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UKillcamPlayback::OnPostLoadMap);
	GameInstance->PlayReplay(TEXT("_Deathcam"), nullptr, AdditionalOptions);

	DuplicateCollection->SetDemoNetDriver(CachedSourceWorld->GetDemoNetDriver());

	KillcamGoToTime(CachedGoToTimeSeconds, CachedFocusActorGUID, FOnGotoTimeDelegate::CreateUObject(this, &UKillcamPlayback::OnKillcamInitialGoToTimeComplete, Delegate));
}

bool UKillcamPlayback::KillcamGoToTime(const float TimeInSeconds, const FNetworkGUID FocusActor, const FOnGotoTimeDelegate& InOnGotoTimeDelegate)
{
	if (UDemoNetDriver* const PlaybackDemoNetDriver = GetPlaybackDemoNetDriver())
	{
		CachedGoToTimeSeconds = TimeInSeconds;
		CachedFocusActorGUID = FocusActor;

		// Reset the timer for automatically switching back to the live world. It will be set when the
		// local hero dies in the killcam world.
		SourceWorld->GetTimerManager().ClearTimer(KillcamAutoSwitchToLiveTimerHandle);

		for (const FNetworkGUID Guid : SavedNonQueuedGUIDs)
		{
			PlaybackDemoNetDriver->AddNonQueuedGUIDForScrubbing(Guid);
		}

		PlaybackDemoNetDriver->GotoTimeInSeconds(TimeInSeconds, InOnGotoTimeDelegate);

		return true;
	}

	return false;
}

void UKillcamPlayback::OnKillcamInitialGoToTimeComplete(bool bWasSuccessful, FOnKillcamStartComplete StartCompleteDelegate)
{
	if (bWasSuccessful)
	{
		ShowKillcamToUser(StartCompleteDelegate);
	}
	else
	{
		// If the scrub to the starting time failed, abort playback, there's nothing else we can do.
		if (UDemoNetDriver* const PlaybackDemoNetDriver = GetPlaybackDemoNetDriver())
		{
			PlaybackDemoNetDriver->StopDemo();
		}
		StartCompleteDelegate.ExecuteIfBound(bWasSuccessful);
	}
}

FString UKillcamPlayback::GetKillcamReplayStreamerName()
{
	return TEXT("InMemoryNetworkReplayStreaming");
}

bool UKillcamPlayback::IsKillcamActor(const AActor* const Actor)
{
	const ULevel* const ActorLevel = Actor ? Actor->GetLevel() : nullptr;
	const FLevelCollection* const ActorLevelCollection = ActorLevel ? ActorLevel->GetCachedLevelCollection() : nullptr;
	return ActorLevelCollection && ActorLevelCollection->GetType() == ELevelCollectionType::DynamicDuplicatedLevels;
}

ULocalPlayer_Game* UKillcamPlayback::GetLocalPlayerFromKillcamPlayerState(const APlayerState_Game* const PlayerState)
{
	if (PlayerState == nullptr)
	{
		return nullptr;
	}

	if (!IsKillcamActor(PlayerState))
	{
		return nullptr;
	}

	if (const UGameInstance* const GameInstance = PlayerState->GetGameInstance())
	{
		return GameInstance->FindLocalPlayerFromUniqueNetId(PlayerState->UniqueId.GetUniqueNetId());
	}

	return nullptr;
}

UKillcamPlayback* UKillcamPlayback::GetPlaybackManagerForKillcamWorld(const UGameInstance* const GameInstance, const UWorld* const World)
{
	if (GameInstance != nullptr && World != nullptr)
	{
		for (auto PlayerIt = GameInstance->GetLocalPlayerIterator(); PlayerIt; ++PlayerIt)
		{
			const ULocalPlayer_Game* const Player = Cast<ULocalPlayer_Game>(*PlayerIt);
			if (Player)
			{
				return Player->GetKillcamPlaybackManager();
			}
		}
	}

	return nullptr;
}

bool UKillcamPlayback::IsEnabled() const
{
	return bIsEnabled;
}

void UKillcamPlayback::KillcamStop(FOnKillcamStopComplete Delegate)
{
	if (bIsPlaying)
	{
		HideKillcamFromUser(Delegate);
	}
	else
	{
		Delegate.ExecuteIfBound();
	}
}

void UKillcamPlayback::CleanUpKillcam(UWorld* World, bool bSessionEnded, bool bCleanupResources)
{
	UWorld* const CachedSourceWorld = SourceWorld.Get();

	if ( !CachedSourceWorld || CachedSourceWorld != World )
	{
		return;
	}

	CachedSourceWorld->GetTimerManager().ClearTimer(KillcamAutoSwitchToLiveTimerHandle);

	FWorldContext* SourceWorldContext = GEngine->GetWorldContextFromWorld(World);
	if (SourceWorldContext != nullptr && KillcamWorld != nullptr)
	{
		check(SourceWorldContext->OwningGameInstance != nullptr);
		check(SourceWorldContext->OwningGameInstance->GetEngine() != nullptr);

		for (FActorIterator ActorIt(KillcamWorld); ActorIt; ++ActorIt)
		{
			// Is LevelTransition the best reason to use here?
			ActorIt->RouteEndPlay(EEndPlayReason::LevelTransition);
		}

		KillcamWorld->CleanupWorld();

		if( GEngine )
		{
			GEngine->WorldDestroyed(KillcamWorld);
		}
		KillcamWorld->RemoveFromRoot();

		// mark everything else contained in the world to be deleted
		for (auto LevelIt(KillcamWorld->GetLevelIterator()); LevelIt; ++LevelIt)
		{
			const ULevel* Level = *LevelIt;
			if (Level)
			{
				CastChecked<UWorld>(Level->GetOuter())->MarkObjectsPendingKill();
			}
		}

		SourceWorldContext->OwningGameInstance->GetEngine()->DestroyWorldContext(KillcamWorld);
	}
	bIsPlaying = false;
	KillcamWorld = nullptr;
	KillcamWorldPackage = nullptr;
}

AActor* UKillcamPlayback::GetLiveActorFromKillcamActor(const AActor* const InKillcamActor) const
{
	if (InKillcamActor && KillcamWorld && KillcamWorld->GetDemoNetDriver())
	{
		UWorld* const CachedSourceWorld = SourceWorld.Get();
		if (CachedSourceWorld && CachedSourceWorld->GetDemoNetDriver())
		{
			const FNetworkGUID ActorNetGUID = KillcamWorld->GetDemoNetDriver()->GetGUIDForActor(InKillcamActor);

			if (ActorNetGUID.IsValid())
			{
				return CachedSourceWorld->GetDemoNetDriver()->GetActorForGUID(ActorNetGUID);
			}
		}
	}

	return nullptr;
}

void UKillcamPlayback::OnKillcamReady(bool bWasSuccessful, FNetworkGUID InKillcamViewTargetGuid)
{
	if (!bWasSuccessful)
	{
		return;
	}

	// If the killcam viewtarget guid is valid, try to follow it
	ULocalPlayer_Game* LocalPlayer = Cast<ULocalPlayer_Game>(GetOuter());
	if (!InKillcamViewTargetGuid.IsValid() || LocalPlayer == nullptr)
	{
		return;
	}

	if (KillcamWorld == nullptr || KillcamWorld->GetDemoNetDriver() == nullptr)
	{
		// Cancel killcam
		KillcamStop(FOnKillcamStopComplete());
		return;
	}
}

void UKillcamPlayback::ShowKillcamToUser(FOnKillcamStartComplete StartCompleteDelegate)
{
	QueueTaskForNextTick(FKillcamTaskDelegate::CreateUObject(this, &UKillcamPlayback::ShowKillcamToUser_Internal, StartCompleteDelegate));
}

void UKillcamPlayback::ShowKillcamToUser_Internal(FOnKillcamStartComplete StartCompleteDelegate)
{
	if (SourceWorld.IsValid())
	{
		FLevelCollection* const SourceCollection = SourceWorld->FindCollectionByType(ELevelCollectionType::DynamicSourceLevels);
		FLevelCollection* const DuplicatedCollection = SourceWorld->FindCollectionByType(ELevelCollectionType::DynamicDuplicatedLevels);
		
		if (SourceCollection && DuplicatedCollection)
		{
			/** 
			 * NOTE: This is where Paragon would notify the player controller to start viewing the deathcam.
			 * The controller's view target would be changed to the copy of the player's hero in the replay world,
			 * and the server would be notified that the player's deathcam has started.
			 * Lastly, the normal game's camera component would be deactivated, and a separate death cam camera
			 * component would be activated which would start viewing the hero that killed the local player.
			 * The GameState would also be notified here that the deathcam had started.
			 */

			SourceCollection->SetIsVisible(false);

			for (ULevel* Level : SourceCollection->GetLevels())
			{
				if (Level)
				{
					for (AActor* Actor : Level->Actors)
					{
						if (!Actor)
						{
							continue;
						}

						for (UActorComponent* Comp : Actor->GetComponents())
						{
							// This will ensure the components are shown again
							Comp->MarkRenderStateDirty();
						}
					}
				}
			}

			DuplicatedCollection->SetIsVisible(true);

			StartCompleteDelegate.ExecuteIfBound(true);
			return;
		}
	}

	StartCompleteDelegate.ExecuteIfBound(false);
}

void UKillcamPlayback::HideKillcamFromUser(FOnKillcamStopComplete Delegate)
{
	QueueTaskForNextTick(FKillcamTaskDelegate::CreateUObject(this, &UKillcamPlayback::HideKillcamFromUser_Internal, Delegate));
}

void UKillcamPlayback::HideKillcamFromUser_Internal(FOnKillcamStopComplete Delegate)
{
	if (!SourceWorld.IsValid())
	{
		Delegate.ExecuteIfBound();
		return;
	}

	// Since we won't be seeing the killcam levels until the next death, we can destroy
	// all non-startup actors in the world and clean up the replay connection here.
	
	FLevelCollection* const DuplicatedCollection = SourceWorld->FindCollectionByType(ELevelCollectionType::DynamicDuplicatedLevels);
	if (DuplicatedCollection)
	{
		// Set the context for this collection on the main world for the DestroyActor call.
		FScopedLevelCollectionContextSwitch CS(DuplicatedCollection, SourceWorld.Get());

		if (SourceWorld->GetDemoNetDriver())
		{
			// Null all startup actors on their channels so that they're not destroyed
			// when the netdriver cleans up (these actors need to stay around)
			UNetConnection* const ServerConnection = SourceWorld->GetDemoNetDriver()->ServerConnection;
			for (UChannel* OpenChannel : ServerConnection->OpenChannels)
			{
				if (OpenChannel != nullptr)
				{
					UActorChannel* const ActorChannel = Cast<UActorChannel>(OpenChannel);
					if (ActorChannel != nullptr && ActorChannel->Actor != nullptr && ActorChannel->Actor->IsNetStartupActor())
					{
						ActorChannel->Actor = nullptr;
					}
				}
			}

			for (ULevel* Level : DuplicatedCollection->GetLevels())
			{
				if (Level)
				{
					for (int32 ActorIndex = Level->Actors.Num() - 1; ActorIndex >= 0; --ActorIndex)
					{
						AActor* const Actor = Level->Actors[ActorIndex];
						if (!Actor)
						{
							continue;
						}

						if (Actor->IsNetStartupActor())
						{
							// Destroy all non-net startup components on this actor. This ensures things
							// like UParticleSystemCompoents that were added to the WorldSettings actor get cleaned up.
							TInlineComponentArray<UActorComponent*> Components;
							Actor->GetComponents(Components);
							for (UActorComponent* Component : Components)
							{
								if (!Component->IsNetStartupComponent())
								{
									Component->DestroyComponent();
								}
							}
						}
						else
						{
							SourceWorld->DestroyActor(Actor, true);
						}
					}
				}
			}

			// Make sure the playback driver, connection, and package map get cleaned up.

			// Cache the demo net driver pointer, since after the call to DestroyDemoNetDriver
			// the pointer to it on the world will be null.
			UDemoNetDriver* const DemoDriver = SourceWorld->GetDemoNetDriver();

			SourceWorld->DestroyDemoNetDriver();

			// Mark the package map pending kill before calling CleanUp on the connection since
			// CleanUp will set the package map pointer to null.
			if (DemoDriver->ServerConnection)
			{
				if (DemoDriver->ServerConnection->PackageMap)
				{
					ServerConnection->PackageMap->MarkPendingKill();
				}

				// CleanUp must be called before garbage is collected to keep
				// the sanity checks in the channel cleanup code happy.
				ServerConnection->CleanUp();
				ServerConnection->MarkPendingKill();
			}
			DemoDriver->MarkPendingKill();
		}

		DuplicatedCollection->SetIsVisible(false);
	}		
		
	FLevelCollection* const SourceCollection = SourceWorld->FindCollectionByType(ELevelCollectionType::DynamicSourceLevels);
	
	if (SourceCollection)
	{
		// NOTE: This is where the game state would be notified that the deathcam had ended.

		SourceCollection->SetIsVisible(true);

		for (ULevel* Level : SourceCollection->GetLevels())
		{
			if (Level)
			{
				for (AActor* Actor : Level->Actors)
				{
					if (!Actor)
					{
						continue;
					}

					for (UActorComponent* Comp : Actor->GetComponents())
					{
						// This will ensure the components are shown again
						Comp->MarkRenderStateDirty();
					}
				}
			}
		}
	}

	// Remove duplicated levels from the world
	if (DuplicatedCollection)
	{
		// Set the context for this collection on the main world for the DestroyActor call.
		FScopedLevelCollectionContextSwitch CS(DuplicatedCollection, SourceWorld.Get());

		for (ULevel* DupLevel : DuplicatedCollection->GetLevels())
		{
			if (DupLevel)
			{
				while (DupLevel->bIsVisible)
				{
					SourceWorld->RemoveFromWorld(DupLevel);
				}
			}
		}

		DuplicatedCollection->SetDemoNetDriver(nullptr);
	}

	// Optionally collect garbage, since we just destroyed a large number of objects.
	if (CVarKillcamGarbageCollectOnExit.GetValueOnGameThread() != 0)
	{
		const double GCStartTimeSeconds = FPlatformTime::Seconds();
		CollectGarbage(GARBAGE_COLLECTION_KEEPFLAGS);
		const double GCEndTimeSeconds = FPlatformTime::Seconds();

		UE_LOG(LogKillcam, Verbose, TEXT("UKillcamPlayback::HideKillcamFromUser: garbage collection took %.3fms."),
			(GCEndTimeSeconds - GCStartTimeSeconds) * 1000.0);
	}

	bIsPlaying = false;
	bIsEnabled = false;

	Delegate.ExecuteIfBound();

	/**
	 * NOTE: This is where the player controller would be notified to stop viewing the deathcam.
	 * This would set the client's view target to a saved view target sent from the server (this was sent during killcam
	 * playback, and was saved to prevent the client from switching view targets while the killcam is playing).
	 * It also notified the server that the player's deathcam has stopped.
	 */
}

void UKillcamPlayback::OnPostLoadMap(UWorld*)
{
	FCoreUObjectDelegates::PostLoadMapWithWorld.Remove(OnPostLoadMapHandle);
	SetPlaybackWorldShouldTick(false);
}

void UKillcamPlayback::SetPlaybackWorldShouldTick(const bool bShouldTick)
{
	// Even ticking the playback world while it's paused can have significant overhead. Prevent any ticking of this world
	// at all until we actually need to display it to the user.
	if (KillcamWorld)
	{
		KillcamWorld->SetShouldTick(bShouldTick);
	}
}

static void HandleKillcamPlayCommand(const TArray<FString>& Args, UWorld* InWorld)
{
	FString Temp;
	const TCHAR* ErrorString = nullptr;

	if ( Args.Num() < 1 )
	{
		ErrorString = TEXT( "You must specify a filename" );
	}
	else if ( InWorld == nullptr )
	{
		ErrorString = TEXT( "InWorld is null" );
	}
	else if ( InWorld->GetGameInstance() == nullptr )
	{
		ErrorString = TEXT( "InWorld->GetGameInstance() is null" );
	}

	if ( ErrorString != nullptr )
	{
		UE_LOG(LogKillcam, Log, TEXT("%s"), *ErrorString );

		if ( InWorld->GetGameInstance() != nullptr )
		{
			InWorld->GetGameInstance()->HandleDemoPlaybackFailure( EDemoPlayFailure::Generic, FString( ErrorString ) );
		}
	}
	else
	{
		ULocalPlayer_Game* LocalPlayer = Cast<ULocalPlayer_Game>(InWorld->GetFirstLocalPlayerFromController());
		if (LocalPlayer != nullptr && LocalPlayer->GetKillcamPlaybackManager() != nullptr)
		{
			LocalPlayer->GetKillcamPlaybackManager()->PlayKillcamReplay( Temp );
		}
	}
}

void UKillcamPlayback::HandleKillcamToggleCommand(UWorld* InWorld)
{
	const TCHAR* ErrorString = nullptr;

	// Toggles the killcam flag in the game viewport client
	if ( InWorld == nullptr )
	{
		ErrorString = TEXT( "InWorld is null" );
		return;
	}

	ULocalPlayer_Game* LocalPlayer = Cast<ULocalPlayer_Game>(InWorld->GetFirstLocalPlayerFromController());
	if (LocalPlayer != nullptr)
	{
		UKillcamPlayback* LocalKillcamPlayback = LocalPlayer->GetKillcamPlaybackManager();
		if (LocalKillcamPlayback != nullptr)
		{
			if (!LocalKillcamPlayback->IsPlaying())
			{
				LocalKillcamPlayback->ShowKillcamToUser(FOnKillcamStartComplete());
			}
			else
			{
				LocalKillcamPlayback->HideKillcamFromUser(FOnKillcamStopComplete());
			}
		}
	}
}

void UKillcamPlayback::NotifySetEnableKillcamOption(const bool bEnabled)
{
	// If toggled on, start recording. If toggled off, stop recording.
	UWorld* const CachedSourceWorld = SourceWorld.Get();

	if (bEnabled)
	{
		if(CachedSourceWorld && CachedSourceWorld->GetDemoNetDriver())
		{
			if (CachedSourceWorld->GetDemoNetDriver()->IsRecordingPaused())
			{
				LastRecordUnpauseTimeSeconds = CachedSourceWorld->GetDemoNetDriver()->DemoCurrentTime;
			}

			CachedSourceWorld->GetDemoNetDriver()->PauseRecording(false);
		}
	}
	else
	{
		HideKillcamFromUser(FOnKillcamStopComplete());

		if(CachedSourceWorld && CachedSourceWorld->GetDemoNetDriver())
		{
			CachedSourceWorld->GetDemoNetDriver()->PauseRecording(true);
		}
	}
}

void UKillcamPlayback::SetUpKillcam(UWorld* const InSourceWorld)
{
	QueueTaskForNextTick(FKillcamTaskDelegate::CreateUObject(this, &UKillcamPlayback::SetUpKillcam_Internal, InSourceWorld));
}

void UKillcamPlayback::SetUpKillcam_Internal(UWorld* const InSourceWorld)
{
	if (InSourceWorld == nullptr)
	{
		return;
	}

	UGameInstance* const GameInstance = InSourceWorld->GetGameInstance();

	FLevelCollection* const SourceLevels = InSourceWorld->FindCollectionByType(ELevelCollectionType::DynamicSourceLevels);

	if (SourceLevels == nullptr)
	{
		return;
	}

	if (bIsPlaying)
	{
		HideKillcamFromUser_Internal(FOnKillcamStopComplete());
	}

	// Use the source context for setting up killcam
	FScopedLevelCollectionContextSwitch LevelContext(SourceLevels, InSourceWorld);

	// Don't record for killcam if this world is already playing back or recording a replay.
	UDemoNetDriver* const DemoDriver = InSourceWorld ? InSourceWorld->GetDemoNetDriver() : nullptr;
	const bool bIsPlayingReplay = DemoDriver && DemoDriver->IsPlaying();

	// Set up killcam recording and playback here, after the game mode class is received, since
	// the replay system uses the game mode to determine the class of the spectator controller to spawn.
	if (URuntimeOptions_Game::Get().IsDeathcamEnabled() && !bIsPlayingReplay && GameInstance != nullptr && InSourceWorld->GetNetMode() == NM_Client)
	{
		// Since the killcam world will also have ReceivedGameModeClass() called in it, detect that and
		// don't try to start recording again. Killcam world contexts will have a valid PIEInstance for now.
		// Revisit when killcam is supported in PIE.
		FWorldContext* const Context = GEngine->GetWorldContextFromWorld(InSourceWorld);
		if (Context == nullptr || Context->PIEInstance != INDEX_NONE || Context->WorldType == EWorldType::PIE)
		{
			return;
		}

		const bool bIsRecordingReplay = DemoDriver && DemoDriver->IsRecording();

		const TCHAR* KillcamReplayName = TEXT("_DeathCam");

		if (!bIsRecordingReplay)
		{
			SourceWorld = InSourceWorld;

			// Start recording the replay for killcam, always using the in memory streamer.
			TArray<FString> AdditionalOptions;
			AdditionalOptions.Add(TEXT("ReplayStreamerOverride=InMemoryNetworkReplayStreaming"));
			AdditionalOptions.Add(TEXT("SkipSpawnSpectatorController"));
			GameInstance->StartRecordingReplay(KillcamReplayName, KillcamReplayName, AdditionalOptions);
			
			// Assuming the in-memory streamer will succeed immediately.
			UDemoNetDriver* const RecordingDemoDriver = InSourceWorld ? InSourceWorld->GetDemoNetDriver() : nullptr;
			
			FLevelCollection& SourceLevels = InSourceWorld->FindOrAddCollectionByType(ELevelCollectionType::DynamicSourceLevels);
			SourceLevels.SetDemoNetDriver(RecordingDemoDriver);
			
			if (RecordingDemoDriver)
			{
				// Set up options to limit killcam recording time.
				RecordingDemoDriver->SetMaxDesiredRecordTimeMS(CVarKillcamMaxDesiredRecordTimeMS.GetValueOnGameThread());
				RecordingDemoDriver->SetActorPrioritizationEnabled(true);
				RecordingDemoDriver->SetViewerOverride(GameInstance->GetFirstLocalPlayerController(InSourceWorld));
				RecordingDemoDriver->SetCheckpointSaveMaxMSPerFrame(CVarKillcamCheckpointSaveMaxMSPerFrame.GetValueOnGameThread());

				// Limit memory usage of the recording replay streamer.
				if (RecordingDemoDriver->ReplayStreamer.IsValid())
				{
					RecordingDemoDriver->ReplayStreamer->SetTimeBufferHintSeconds(CVarKillcamBufferTimeInSeconds.GetValueOnGameThread());
				}
			}
		}
	}
}

void UKillcamPlayback::OnLocalHeroDeath(const APlayerState_Game* const DyingPlayer, const ACharHero* const DyingHero, const APlayerState_Game* const KillingPlayer, const AActor* const DamageCauser)
{
	if (DyingPlayer == nullptr)
	{
		UE_LOG(LogKillcam, Log, TEXT("Instant replay: OnLocalHeroDeath. DyingPlayer player state is null!"));
		return;
	}

	if (DyingHero == nullptr)
	{
		UE_LOG(LogKillcam, Log, TEXT("Instant replay: OnLocalHeroDeath. DyingHero character is null!"));
		return;
	}

	UWorld* const CachedSourceWorld = SourceWorld.Get();
	if (CachedSourceWorld == nullptr)
	{
		return;
	}

	// This should only happen for live, non-replay players
	if (!ensure(!IsKillcamActor(DyingPlayer)))
	{
		return;
	}

	// If we're recording, cache some information about the dying hero
	// that will be used when playing back the replay.
	if (CachedSourceWorld->GetDemoNetDriver())
	{
		// Save the NetGUID of the hero so that we can find the same hero
		// in the replay and set it as the player's view target.
		CachedFocusActorGUID = CachedSourceWorld->GetDemoNetDriver()->GetGUIDForActor(DyingHero);

		// Save the demo time of the death so that we can scrub to the correct
		// starting time consistently.
		CachedHeroDeathDemoTime = CachedSourceWorld->GetDemoNetDriver()->DemoCurrentTime;

		// Save the client world time so that we can prevent the player from
		// entering deathcam for short time.
		CachedHeroDeathClientWorldTime = CachedSourceWorld->GetTimeSeconds();

		// Save the NetGUID of the actor that killed the local hero so that the camera can
		// try to keep it in the frame during playback.
		CachedKillingActorGUID = CachedSourceWorld->GetDemoNetDriver()->GetGUIDForActor(DamageCauser);
	}
}

void UKillcamPlayback::OnHeroDeath(const ACharHero* const DyingHero)
{
	if (DyingHero == nullptr)
	{
		return;
	}

	UWorld* const CachedSourceWorld = SourceWorld.Get();
	if (CachedSourceWorld == nullptr)
	{
		return;
	}

	// If we're playing back, start a timer when the watched hero dies to switch back
	// to viewing the live world.
	if (IsKillcamActor(DyingHero))
	{
		const UDemoNetDriver* const DemoNetDriver = GetPlaybackDemoNetDriver();
		if (DemoNetDriver && DemoNetDriver->GetGUIDForActor(DyingHero) == GetFocusActorGUID())
		{
			if (CachedSourceWorld)
			{
				CachedSourceWorld->GetTimerManager().SetTimer(
					KillcamAutoSwitchToLiveTimerHandle,
					FTimerDelegate::CreateUObject(this, &UKillcamPlayback::RequestTransitionReplayToLive),
					CVarKillcamAutoSwitchToLiveAfterDeathTimeInSeconds.GetValueOnGameThread(),
					false);
			}
		}
	}
}

void UKillcamPlayback::RequestTransitionReplayToLive()
{
	// Can't start this transition if we're not playing.
	if (!IsPlaying())
	{
		return;
	}

	if (UHUDContext* const HUDContext = UHUDContext::GetCurrent(GetOuter()))
	{
		UAnalytics_Game::FireEvent_InstantReplayStop(HUDContext->GetPlayerController<APlayerController_Game>());

		HUDContext->HideKillCam(EHUDShowKillCamMode::Fade);
	}
}

bool UKillcamPlayback::IsPlaybackAllowed() const
{
	// Don't play if the runtime option is disabled.
	if (!URuntimeOptions_Game::Get().IsDeathcamEnabled())
	{
		return false;
	}

	if (IsPlaying())
	{
		return false;
	}

	const UWorld* const CachedSourceWorld = SourceWorld.Get();

	if (CachedSourceWorld == nullptr)
	{
		return false;
	}

	// Only play on clients.
	if (CachedSourceWorld->GetNetMode() != NM_Client)
	{
		return false;
	}

	const UGameInstance* const GameInstance = CachedSourceWorld->GetGameInstance();

	// We should always have a game instance.
	if (!ensure(GameInstance != nullptr))
	{
		return false;
	}

	// Playback is currently not supported in PIE.
	if (GameInstance->GetWorldContext() != nullptr && GameInstance->GetWorldContext()->WorldType == EWorldType::PIE)
	{
		return false;
	}

	const FLevelCollection* const DuplicateCollection = SourceWorld->FindCollectionByType(ELevelCollectionType::DynamicDuplicatedLevels);
	
	// Can't start playback if there aren't any duplicated levels in which to play the replay.
	if (!DuplicateCollection)
	{
		return false;
	}

	const ULocalPlayer_Game* const LocalPlayer = Cast<ULocalPlayer_Game>(GetOuter());
	if (LocalPlayer == nullptr)
	{
		return false;
	}

	const APlayerController_Game* const PlayerController = Cast<APlayerController_Game>(LocalPlayer->GetPlayerController(SourceWorld.Get()));
	if (PlayerController == nullptr)
	{
		return false;
	}

	if (!PlayerController->IsInState(NAME_Spectating) || !PlayerController->IsLocalController())
	{
		return false;
	}

	// If the player's pawn is an Char, make sure it's dead.
	// Get the pawn through the PlayerState since the Pawn's controller may have been nulled out by now.
	const APlayerState_Game* const PlayerState = Cast<APlayerState_Game>(PlayerController->PlayerState);
	const AChar* const CharPawn = PlayerState ? PlayerState->GetCurrentPawn() : nullptr;
	if (CharPawn && !CharPawn->HasFinishedDying())
	{
		return false;
	}

	return true;
}

UDemoNetDriver* UKillcamPlayback::GetPlaybackDemoNetDriver() const
{
	const UWorld* const CachedSourceWorld = SourceWorld.Get();
	if (CachedSourceWorld == nullptr)
	{
		return nullptr;
	}

	const FLevelCollection* const PlaybackLevels = CachedSourceWorld->FindCollectionByType(ELevelCollectionType::DynamicDuplicatedLevels);
	if (PlaybackLevels != nullptr)
	{
		return PlaybackLevels->GetDemoNetDriver();
	}

	return nullptr;
}

static void HandleKillcamDebugShowHUDCommand(UWorld* InWorld)
{
	if ( InWorld == nullptr )
	{
		return;
	}

	if (ULocalPlayer_Game* const LocalPlayer = Cast<ULocalPlayer_Game>(InWorld->GetFirstLocalPlayerFromController()))
	{
		if (UHUDContext* const HUDContext = UHUDContext::GetCurrent(LocalPlayer))
		{
			HUDContext->ShowKillCam(EHUDShowKillCamMode::Fade);
		}
	}
}

static void HandleKillcamDebugHideHUDCommand(UWorld* InWorld)
{
	if (InWorld == nullptr)
	{
		return;
	}

	if (ULocalPlayer_Game* const LocalPlayer = Cast<ULocalPlayer_Game>(InWorld->GetFirstLocalPlayerFromController()))
	{
		if (UHUDContext* const HUDContext = UHUDContext::GetCurrent(LocalPlayer))
		{
			HUDContext->HideKillCam(EHUDShowKillCamMode::Fade);
		}
	}
}

static void HandleKillcamDebugForceHide(UWorld* InWorld)
{
	if (InWorld == nullptr)
	{
		return;
	}

	if (APlayerController_Game* const PC = Cast<APlayerController_Game>(InWorld->GetFirstPlayerController()))
	{
		PC->DisableKillcam_Local();
	}
}

FAutoConsoleCommandWithWorldAndArgs KillcamPlayCommand(
	TEXT("Killcam.Play"),
	TEXT("Plays the replay with the given name in the killcam playback world."),
	FConsoleCommandWithWorldAndArgsDelegate::CreateStatic(HandleKillcamPlayCommand));

FAutoConsoleCommandWithWorld KillcamToggleCommand(
	TEXT("Killcam.Toggle"),
	TEXT("Switches the active world for the viewport to the killcam world"),
	FConsoleCommandWithWorldDelegate::CreateStatic(UKillcamPlayback::HandleKillcamToggleCommand));

FAutoConsoleCommandWithWorld KillcamDebugShowHUDCommand(
	TEXT("Killcam.DebugShowHUD"),
	TEXT("Shows the killcam HUD elements for debugging purposes."),
	FConsoleCommandWithWorldDelegate::CreateStatic(HandleKillcamDebugShowHUDCommand));

FAutoConsoleCommandWithWorld KillcamDebugHideHUDCommand(
	TEXT("Killcam.DebugHideHUD"),
	TEXT("Hides the killcam HUD elements for debugging purposes."),
	FConsoleCommandWithWorldDelegate::CreateStatic(HandleKillcamDebugHideHUDCommand));

FAutoConsoleCommandWithWorld KillcamDebugForceHide(
	TEXT("Killcam.DebugForceHide"),
	TEXT("Forcibly ends killcam playback with a HUD cut for debugging purposes."),
	FConsoleCommandWithWorldDelegate::CreateStatic(&HandleKillcamDebugForceHide));
